/**
 * Side length of a standard room cell.
 */
const SINGLE_CELL_SIDE_LENGTH = 5;

export { SINGLE_CELL_SIDE_LENGTH };